package br.com.unipar.poo;

public class Lobo extends Personagem{
    public Lobo(String nome){
        super(nome, 1, 1, 12, 0, true);

        calcularVida(2, 8, 13);
    }

    @Override
    public int ataque1() {
        int dano = calcularDano(1, 6, 7);
        return dano;
    }

    @Override
    public String nomeAtaque1() {
        return "Mordida";
    }
}
