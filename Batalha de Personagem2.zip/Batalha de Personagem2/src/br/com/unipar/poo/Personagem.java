package br.com.unipar.poo;

public class Personagem {
    Dados dados = new Dados();
    private String nome;
    private int vidaMaxima;
    private int vidaAtual;
    private int ca;
    private boolean vivo;
    private int qntdPocoes;

    Personagem(String nome, int vidaMaxima, int vidaAtual, int ca, int qntdPocoes, boolean vivo) {
        this.nome = nome;
        this.vidaMaxima = vidaMaxima;
        this.vidaAtual = vidaAtual;
        this.ca = ca;
        this.qntdPocoes = qntdPocoes;
        this.vivo = vivo;
    }

    public Personagem() {
    }

    //Nome
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    //Vida Maxima

    public int calcularVida(int qntdDados, int qntdFaces, int bonus){
        int vida = dados.rolar(qntdDados, qntdFaces) + bonus;

        vidaMaxima = vida;
        vidaAtual = vida;
        return vida;
    }

    public void setVidaMaxima(int vidaMaxima) {
        this.vidaMaxima = vidaMaxima;
    }

    public int getVidaMaxima() {
        return vidaMaxima;
    }

    //Vida Atual
    public void setVidaAtual(int vidaAtual) {
        this.vidaAtual = vidaAtual;
    }

    public int getVidaAtual() {
        return vidaAtual;
    }

    //CA
    public void setCa(int ca) {
        this.ca = ca;
    }

    public int getCa() {
        return ca;
    }

    //Qntd de Poções
    public int getQntdPocoes() {
        return qntdPocoes;
    }

    //Vivo
    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }

    public boolean getVivo() {
        return vivo;
    }

    //Teste D20
    public int testeD20(){
        int testeD20 = dados.rolar(1,20);
        return testeD20;
    }

    //ataques
    public int calcularDano(int qntdDados, int qntdFaces, int bonusAtaque){
        int dano = dados.rolar(qntdDados, qntdFaces);
        dano += bonusAtaque;
        return dano;
    }

    public int ataque1(){
        return 0;
    }

    public String nomeAtaque1(){
        return "Ataque genérico";
    }

    public String informacoesAtaque1(int qntdDados, int qntdFaces,int danoBonus){
        return danoBonus + " + " + qntdDados + "d" + qntdFaces;
    }

    public String informacoesAtaque1(){
        return informacoesAtaque1(1,2,3);
    }

    //Habilidade
    public int habilidade1(){
        return 0;
    }

    //Danos
    public int receberDano(int dano){
        vidaAtual -= dano;

        if(vidaAtual < 0){
            vidaAtual = 0;
        }
        return vidaAtual;
    }

    //Recuperar Vida
    public int calcularVidaRecuperada(int qntdDados, int qntdFaces){
        int calcularVida = dados.rolar(qntdDados, qntdFaces);
        return calcularVida;
    }

    public String recuperarVida(int qntdDados, int qntdFaces){
        if(qntdPocoes > 0){
            int vidaRecuperada = calcularVidaRecuperada(qntdDados, qntdFaces);
            vidaAtual += vidaRecuperada;
            qntdPocoes--;

            if (vidaAtual >= vidaMaxima){
                vidaAtual = vidaMaxima;
            return "Vida recuperada por completo";
            }

            return "Voce recuperou +" + vidaRecuperada + "\nVida Atual " + vidaAtual;
        } else{
            return "Sem poções disponiveis";
        }
    }

    public String recuperarVida(){
        return recuperarVida(1,8);
    }

    public String informacoesCura(){
        return "cura padrão";
    }

    public void informacoesPersonagem(){
        System.out.println("Status de " + nome);
        System.out.println("Vida Máxima " + vidaMaxima);
        System.out.println("CA " + ca);
        System.out.println("Ataques \n" + nomeAtaque1());
    }
}