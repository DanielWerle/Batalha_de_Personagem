package br.com.unipar.poo;

public class Esqueleto extends Personagem{
    public Esqueleto(){
        super("Esqueleto", 1, 1, 13, 0, true);
        calcularVida(2,8,17);
    }

    @Override
    public int ataque1() {
        int dano = calcularDano(1,6,9);
        return dano;
    }

    @Override
    public String nomeAtaque1() {
        return "Espada Curta";
    }

    @Override
    public int testeD20() {
        return super.testeD20() + 5;
    }
}
