package br.com.unipar.poo;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Util u = new Util();
        Random random = new Random();

        Personagem player = new Personagem();
        ClassePersonagem classeSelecionadaEnum;
        Personagem infoPersonagem;

        //Escolha de Classe
        do {
            System.out.println("Escolha sua Classe *Digite o número");

            //Informações Guerreiro
            System.out.println("1 - Guerreiro");
            infoPersonagem = new Guerreiro("Guerreiro");
            infoPersonagem.informacoesPersonagem();

            //Informações Mago
            System.out.println("\n2 - Mago");
            infoPersonagem = new Mago("Mago");
            infoPersonagem.informacoesPersonagem();

            //Escolha do usuário
            int classeEscolhidaInt = ler.nextInt();

            switch (classeEscolhidaInt) {
                case 1:
                    classeSelecionadaEnum = ClassePersonagem.GUERRRIRO;
                    break;

                case 2:
                    classeSelecionadaEnum = ClassePersonagem.MAGO;
                    break;

                default:
                    System.out.println("Escolha inválida!");
                    classeSelecionadaEnum = null;
                    u.pausarSeg(2);
                    break;
            }
        } while (classeSelecionadaEnum == null);

        //Nome do Herói
        System.out.println("\nEscolha um nome para o seu Herói");
        ler.nextLine();
        String nomePlayer = ler.nextLine();

        //Criação da Classe escolhida
        switch (classeSelecionadaEnum) {
            case GUERRRIRO:
                player = new Guerreiro(nomePlayer);
                break;

            case MAGO:
                player = new Mago(nomePlayer);
                break;

            default:
                System.out.println("Escolha inválida!");
                break;
        }
        player.informacoesPersonagem();

            //Seleção de Pet
            Personagem pet = new Personagem();
            int petEscolhidoInt;
            ClassePersonagem petSelecionadoEnum;

        do{
            System.out.println("\nSelecione o Pet *Digite o número");

            //Informações Leão
            System.out.println("1 - Leão");
            infoPersonagem = new Leao("Leão");
            infoPersonagem.informacoesPersonagem();

            //Informações Tigre
            System.out.println("\n2 - Tigre");
            infoPersonagem = new Tigre("Tigre");
            infoPersonagem.informacoesPersonagem();

            //Informações Lobo
            System.out.println("\n3 - Lobo");
            infoPersonagem = new Lobo("Lobo");
            infoPersonagem.informacoesPersonagem();

            //Escolha do Usuário
            petEscolhidoInt = ler.nextInt();

            switch (petEscolhidoInt) {
                case 1:
                    petSelecionadoEnum = ClassePersonagem.LEAO;
                break;

                case 2:
                    petSelecionadoEnum = ClassePersonagem.TIGRE;
                break;

                case 3:
                    petSelecionadoEnum = ClassePersonagem.LOBO;
                break;

                default:
                    System.out.println("Escolha inválida");
                    petSelecionadoEnum = null;
                    u.pausarSeg(2);
                break;
            }
        }while(petSelecionadoEnum == null);

        System.out.println("\nEscolha o nome para o seu Pet");
        ler.nextLine();
        String nomePet = ler.nextLine();

        switch (petSelecionadoEnum){
            case LEAO:
                pet = new Leao(nomePet);
            break;

            case TIGRE:
                pet = new Tigre(nomePet);
            break;

            case LOBO:
                pet = new Lobo(nomePet);
            break;

            default:
                System.out.println("Escolha inválida");
            break;
        }

        //Inicio da Batalha
        Personagem inimigo = new Esqueleto();

        u.pausarSeg(2);

        System.out.println("\nEm uma dungeon com seu fiel companheiro " + pet.getNome());
        u.pausarSeg(2);

        System.out.println("Vocês encontram uma criatura, você percebe que é um " + inimigo.getNome());
        u.pausarSeg(2);

        System.out.println("Você começa");

        do {
            //Player
            System.out.println("\nTurno de " + player.getNome());
            u.pausarSeg(2);
            System.out.println("\nO que você faz? *Digite o número");

            System.out.println("1 - Atacar com " + player.nomeAtaque1() + " " + player.informacoesAtaque1());
            System.out.println("2 - Se Curar - Recuperará " + player.informacoesCura() + " de vida");
            int acaoPlayer = ler.nextInt();

            switch(acaoPlayer) {
                case 1:
                    int testeD20 = player.testeD20();
                    System.out.println("Voce tirou " + testeD20);
                    u.pausarSeg(2);

                    if (testeD20 > inimigo.getCa()){
                        System.out.println("Voce Acertou!");
                        int dano = player.ataque1();

                        System.out.println("Você causou " + dano + " de dano");
                        inimigo.receberDano(dano);
                    } else {
                        System.out.println("Voce Errou!");
                    }

                    break;

                case 2:
                    System.out.println(player.recuperarVida());
                    System.out.println("Você possui " + player.getQntdPocoes() + " poções");
                    u.pausarSeg(2);
                    break;

                default:
                    System.out.println("Escolha inválida!" +
                            "\nComo penalidade você perdeu o turno");
                    u.pausarSeg(2);
                    break;
            }

            if (pet.getVivo()){
                System.out.println("\nÉ a vez de " + pet.getNome());
                u.pausarSeg(2);

                System.out.println(pet.getNome() + " usa " + pet.nomeAtaque1());
                int testeD20 = pet.testeD20();
                u.pausarSeg(2);

                if(testeD20 > inimigo.getCa()){
                    System.out.println(pet.getNome() + " acerta o ataque");
                    int dano = pet.ataque1();

                    System.out.println("O pet causou " + dano + " de dano no " + inimigo.getNome());
                    inimigo.receberDano(dano);
                } else {
                    System.out.println(pet.getNome() + " errou o ataque");
                }
                u.pausarSeg(2);
            }

            if(inimigo.getVivo()){
                System.out.println("\nÉ a vez de " + inimigo.getNome());
                u.pausarSeg(2);

                System.out.println(inimigo.getNome() + " usa " + inimigo.nomeAtaque1());
                u.pausarSeg(2);

                int dano = inimigo.ataque1();
                int testeD20 = inimigo.testeD20();

                int alvo = random.nextInt(2);

                if (!pet.getVivo()){
                    alvo = 0;
                }


                switch(alvo) {
                    //Ataque contra o player
                    case 0:
                        if (testeD20 > player.getCa()) {
                            System.out.println("O " + inimigo.getNome() + " acertou o ataque em Você!");
                            u.pausarSeg(2);

                            player.receberDano(dano);
                            System.out.println("Causou -" + dano + " de dano");
                            System.out.println("Vida atual " + player.getVidaAtual());
                            u.pausarSeg(2);

                        } else {
                            System.out.println("O " + inimigo.getNome() + " vai te acertar mas erra o ataque");
                            u.pausarSeg(2);
                        }
                        break;

                    //Ataque contra pet
                    case 1:
                        if (testeD20 > pet.getCa()) {
                            System.out.println("O " + inimigo.getNome() + " acerta o ataque em " + pet.getNome());
                            u.pausarSeg(2);

                            pet.receberDano(dano);
                            System.out.println("Causou -" + dano + " de dano");
                            System.out.println("Vida atual de " + pet.getNome() + " " + pet.getVidaAtual());
                            u.pausarSeg(2);

                            if (!pet.getVivo()){
                                System.out.println(pet.getNome() + "não aguentou o ataque e está inconciente");
                            }

                        } else {
                            System.out.println("O " + inimigo.getNome() + " vai acertar o " + pet.getNome() + " mas erra o ataque");
                            u.pausarSeg(2);

                        }
                        break;
                    default:
                        break;
                }
            }
        }while(player.getVivo() && inimigo.getVivo());

        if (!inimigo.getVivo()){
            System.out.println("\nParabens você derrotou o " + inimigo.getNome());
        } else{
            System.out.println("\nEssa não" +
                    "\nVoce perdeu;(" +
                    "\nInsira uma fixa e tente novamente");
        }
    }
}