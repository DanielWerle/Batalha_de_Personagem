package br.com.unipar.poo;

public class Leao extends Personagem{
    public Leao(String nome){
        super(nome, 1, 1, 12, 0, true);
        calcularVida(4,10,22);
    }

    @Override
    public int ataque1() {
        int dano = calcularDano(1,8,10);
        return dano;
    }

    @Override
    public String nomeAtaque1() {
        return "Dilacerar";
    }
}