package br.com.unipar.poo;

import java.util.Random;

public class Dados {
    Random random = new Random();

    public int rolar (int quantidade, int faces){
        int resultadoRolagem = 0;

        for (int i = 0; i < quantidade; i++){
            resultadoRolagem += random.nextInt(faces) + 1;
        }

        return resultadoRolagem;
    }
}