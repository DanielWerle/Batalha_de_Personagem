package br.com.unipar.poo;

public class Tigre extends Personagem{
    Tigre (String nome){
        super(nome, 1, 1, 13, 0, true);

        calcularVida(3, 10, 28);
    }

    @Override
    public int ataque1() {
        int dano = calcularDano(1, 6, 9);
        return dano;
    }

    @Override
    public int testeD20() {
        return super.testeD20() + 5;
    }

    @Override
    public String nomeAtaque1() {
        return "Bote";
    }
}
