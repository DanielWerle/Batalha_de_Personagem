package br.com.unipar.poo;

public class Mago extends Personagem{
    Mago(String nome){
        super(nome, 36, 36, 16, 5, true);
    }

    @Override
    public int ataque1() {
        int dano = calcularDano(2,10,5);
        return dano;
    }

    @Override
    public String nomeAtaque1() {
        return "Raio de Fogo";
    }

    @Override
    public String informacoesAtaque1() {
        return super.informacoesAtaque1(2,10,5);
    }

    @Override
    public int testeD20() {
        return super.testeD20() + 5;
    }

    @Override
    public String informacoesCura() {
        return 1 + "d" + 6;
    }

    @Override
    public String recuperarVida() {
        return super.recuperarVida(1,6);
    }

    @Override
    public void informacoesPersonagem() {
        super.informacoesPersonagem();
        System.out.println(informacoesAtaque1(2,10,5));
        System.out.println("Quantidade de Poções " + getQntdPocoes());
    }
}
