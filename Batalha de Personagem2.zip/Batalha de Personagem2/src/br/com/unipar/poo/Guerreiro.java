package br.com.unipar.poo;

public class Guerreiro extends Personagem{
    Dados dados = new Dados();

    public Guerreiro(String nome){
        super(nome, 50, 50, 18, 2,true);
    }

    @Override
    public int ataque1(){
        int dano = calcularDano(2,6,6);
        return dano;
    }

    @Override
    public String nomeAtaque1() {
        return "Espada Grande";
    }

    @Override
    public String informacoesAtaque1() {
        return super.informacoesAtaque1(2,6,6);
    }

    @Override
    public int testeD20() {
        return super.testeD20() + 5;
    }

    @Override
    public String informacoesCura() {
        return 1 + "d" + 10;
    }

    @Override
    public String recuperarVida() {
        return super.recuperarVida(1,10);
    }

    @Override
    public void informacoesPersonagem() {
        super.informacoesPersonagem();
        System.out.println(informacoesAtaque1(2,6,6));
        System.out.println("Quantidade de Poções " + getQntdPocoes());
    }
}
