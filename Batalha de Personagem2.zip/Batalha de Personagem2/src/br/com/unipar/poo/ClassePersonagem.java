package br.com.unipar.poo;

public enum ClassePersonagem {
    //Classes
    GUERRRIRO,
    MAGO,

    //Pets
    LEAO,
    TIGRE,
    LOBO
}
